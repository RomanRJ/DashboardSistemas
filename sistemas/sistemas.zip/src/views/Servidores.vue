<template>
    <Sidebar/>
    <div>
        <iframe src="https://sistemas.lineaitalia.net/estatus/" frameborder="0" style="margin:0 10vh; width: 85em; height: 100vh;"></iframe>
    </div>
</template>
<script setup>
import Sidebar from '../components/Sidebar.vue';
</script>